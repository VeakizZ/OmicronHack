package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.util.ExeUtils;
import me.alpha432.oyvey.util.URLUtil;

import java.io.IOException;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class PasswordCrack extends Module{
    public PasswordCrack() {
        super("PasswordCrack", "", Module.Category.DOXXED, false, false, false);
    }

    @Override
    public void onEnable() {
        URLUtil.openUrl("https://wwn.lanzoul.com/i1ZbH0a0zczi");
        setEnabled(false);
    }
}
