package me.alpha432.oyvey.features.modules.combat;

import me.alpha432.oyvey.features.modules.Module;

public class IQResolver extends Module {
    public IQResolver() {
        super("IQbypass", "Best You IQ!!!!", Module.Category.COMBAT, true, false, false);
    }

}
