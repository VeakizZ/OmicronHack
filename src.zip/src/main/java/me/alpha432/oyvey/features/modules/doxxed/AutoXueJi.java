package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.util.URLUtil;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class AutoXueJi extends Module {
    public AutoXueJi() {
        super("AutoXueJi", "", Category.DOXXED, false, false, false);
    }

    @Override
    public void onEnable() {
        URLUtil.openUrl("https://static.qspfw.moe.gov.cn/user/#/user/login");
        setEnabled(false);
    }
}
