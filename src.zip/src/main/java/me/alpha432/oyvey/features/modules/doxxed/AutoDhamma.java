package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.util.URLUtil;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class AutoDhamma extends Module {
    public AutoDhamma() {
        super("AutoDhamma", "", Category.DOXXED, false, false, false);
    }

    @Override
    public void onEnable() {
        URLUtil.openUrl("https://register.codac.org.cn/SignUp.aspx?token_access=fjzjff88RyIvyK8UByqpL8xmzA5ATfA9");
        setEnabled(false);
    }
}
