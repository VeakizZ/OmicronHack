package me.alpha432.oyvey.features.modules.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.Module;
import net.minecraft.entity.player.EntityPlayer;

import java.util.HashMap;

public class TotemPopCounter
        extends Module {
    public static HashMap<String, Integer> TotemPopContainer = new HashMap();
    private static TotemPopCounter INSTANCE = new TotemPopCounter();

    public TotemPopCounter() {
        super("TotemPopCounter", "Counts other players totem pops.", Module.Category.MISC, true, false, true);
        this.setInstance();
    }

    public static TotemPopCounter getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new TotemPopCounter();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        TotemPopContainer.clear();
    }

    public void onDeath(EntityPlayer player) {
        if (TotemPopContainer.containsKey(player.getName())) {
            int l_Count = TotemPopContainer.get(player.getName());
            TotemPopContainer.remove(player.getName());
            if (l_Count == 1) {
                if (TotemPopCounter.mc.player.equals((Object)player)) {
                    Command.sendMessage(ChatFormatting.DARK_RED +"[HitLog] " + ChatFormatting.YELLOW + " You died after popping " + ChatFormatting.GREEN + l_Count + ChatFormatting.YELLOW + " Totem!");
                } else {
                    Command.sendMessage(ChatFormatting.DARK_AQUA +"[TotemPopCounter] " + ChatFormatting.AQUA + player.getName() + " died after popping " + ChatFormatting.GREEN + l_Count + ChatFormatting.AQUA + " Totem!");
                }
            } else if (TotemPopCounter.mc.player.equals((Object)player)) {
                Command.sendMessage(ChatFormatting.DARK_RED +"[HitLog] " + ChatFormatting.YELLOW + " You died after popping " + ChatFormatting.GREEN + l_Count + ChatFormatting.YELLOW + " Totems!");
            } else {
                Command.sendMessage(ChatFormatting.RED +"[DeathPop] " +ChatFormatting.WHITE + player.getName() + " died after popping " + ChatFormatting.GREEN + l_Count + ChatFormatting.RED + " Totems!");
            }
        }
    }

    public void onTotemPop(EntityPlayer player) {
        if (TotemPopCounter.fullNullCheck()) {
            return;
        }
        int l_Count = 1;
        if (TotemPopContainer.containsKey(player.getName())) {
            l_Count = TotemPopContainer.get(player.getName());
            TotemPopContainer.put(player.getName(), ++l_Count);
        } else {
            TotemPopContainer.put(player.getName(), l_Count);
        }
        if (l_Count == 1) {
            if (TotemPopCounter.mc.player.equals((Object)player)) {
                Command.sendMessage(ChatFormatting.DARK_RED +"[HitLog] " + ChatFormatting.YELLOW + " You popped " + ChatFormatting.GREEN + l_Count + ChatFormatting.YELLOW + " Totem.");
            } else {
                Command.sendMessage(ChatFormatting.WHITE +"[TotemPopCounter] " + ChatFormatting.AQUA + player.getName() + " popped " + ChatFormatting.GREEN + l_Count + ChatFormatting.AQUA + " Totem.");
            }
        } else if (TotemPopCounter.mc.player.equals((Object)player)) {
            Command.sendMessage(ChatFormatting.RED +"[YouPoped] " +ChatFormatting.WHITE + "You popped " + ChatFormatting.GREEN + l_Count + ChatFormatting.WHITE + " Totems.");
        } else {
            Command.sendMessage(ChatFormatting.WHITE +"[TotemPopCounter] " + ChatFormatting.AQUA + player.getName() + " popped " + ChatFormatting.GREEN + l_Count + ChatFormatting.AQUA + " Totems.");
        }
    }
}

