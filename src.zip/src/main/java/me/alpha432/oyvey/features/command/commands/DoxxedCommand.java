package me.alpha432.oyvey.features.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.doxxed.DoxxedActivator;
import me.alpha432.oyvey.util.GsonUtils;
import me.alpha432.oyvey.util.URLUtil;
import me.alpha432.oyvey.util.doxxedobj.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class DoxxedCommand extends Command {
    public DoxxedCommand() {
        super("doxxed", new String[]{"<lol/lolfc/qq/qqfc/qqlm/wb/wbfc/sfz/douzi/ssy>", "<QQ/LOLName/QQ/Phone/QQ/WeiBo/Phone/Sfz/<null>/<null>>"});
    }

    @Override
    public void execute(String[] var1) {
        if (!OyVey.moduleManager.isModuleEnabled(DoxxedActivator.class)) {
            sendMessage(ChatFormatting.GRAY + "DoxxedActivatorģ��δ����");
            OyVey.LOGGER.error("DoxxedActivator is disabled");
            return;
        }

        if (var1.length == 0) {
            sendMessage("��������");
            OyVey.LOGGER.error("Arguments error");
            return;
        }

        if (var1[0].equalsIgnoreCase("help")) {
            sendMessage(ChatFormatting.GRAY + OyVey.commandManager.getPrefix() + this.getName() + Arrays.toString(getCommands()));
            return;
        }

        if (var1[0].equalsIgnoreCase("lol")) {
            String s = var1[1];
            StringBuilder stringBuilder = new StringBuilder();
            String inputLine;
            URL url;
            try {
                url = new URL("https://zy.xywlapi.cc/qqlol?qq=" + s);
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8));
                while ((inputLine = in.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
            } catch (IOException e) {
                OyVey.LOGGER.error(e);
                sendMessage(ChatFormatting.RED + e.getMessage());
            }
            OyVey.LOGGER.info(stringBuilder.toString());
            LOLInfo info = GsonUtils.jsonToBean(stringBuilder.toString(), LOLInfo.class);
            sendMessage(ChatFormatting.GRAY + "����״̬: " + info.getStatus());
            sendMessage(ChatFormatting.GRAY + "������Ϣ: " + info.getMessage());
            sendMessage(ChatFormatting.GRAY + "QQ: " + info.getQq());
            sendMessage(ChatFormatting.GRAY + "�ֻ���: " + info.getName());
            sendMessage(ChatFormatting.GRAY + "����: " + info.getDaqu());
        }

        if (var1[0].equalsIgnoreCase("lolfc")) {
            String s = var1[1];
            StringBuilder stringBuilder = new StringBuilder();
            String inputLine;
            URL url;
            try {
                url = new URL("https://zy.xywlapi.cc/lolname?name=" + s);
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8));
                while ((inputLine = in.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
            } catch (IOException e) {
                OyVey.LOGGER.error(e);
                sendMessage(e.getMessage());
            }
            OyVey.LOGGER.info(stringBuilder.toString());
            LOLInfo info = GsonUtils.jsonToBean(stringBuilder.toString(), LOLInfo.class);
            sendMessage(ChatFormatting.GRAY + "����״̬: " + info.getStatus());
            sendMessage(ChatFormatting.GRAY + "������Ϣ: " + info.getMessage());
            sendMessage(ChatFormatting.GRAY + "QQ: " + info.getQq());
            sendMessage(ChatFormatting.GRAY + "�ֻ���: " + info.getName());
            sendMessage(ChatFormatting.GRAY + "����: " + info.getDaqu());
        }

        if (var1[0].equalsIgnoreCase("qq")) {
            String s = var1[1];
            StringBuilder stringBuilder = new StringBuilder();
            String inputLine;
            URL url;
            try {
                url = new URL("https://zy.xywlapi.cc/qqapi?qq=" + s);
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8));
                while ((inputLine = in.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
            } catch (IOException e) {
                OyVey.LOGGER.error(e);
                sendMessage(e.getMessage());
            }
            OyVey.LOGGER.info(stringBuilder.toString());
            QQInfo info = GsonUtils.jsonToBean(stringBuilder.toString(), QQInfo.class);
            sendMessage(ChatFormatting.GRAY + "����״̬: " + info.getStatus());
            sendMessage(ChatFormatting.GRAY + "������Ϣ: " + info.getMessage());
            sendMessage(ChatFormatting.GRAY + "QQ: " + info.getQq());
            sendMessage(ChatFormatting.GRAY + "�ֻ���: " + info.getPhone());
            sendMessage(ChatFormatting.GRAY + "����: " + info.getPhonediqu());
        }

        if (var1[0].equalsIgnoreCase("qqfc")) {
            String s = var1[1];
            StringBuilder stringBuilder = new StringBuilder();
            String inputLine;
            URL url;
            try {
                url = new URL("https://zy.xywlapi.cc/qqphone?phone=" + s);
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8));
                while ((inputLine = in.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
            } catch (IOException e) {
                OyVey.LOGGER.error(e);
                sendMessage(e.getMessage());
            }
            OyVey.LOGGER.info(stringBuilder.toString());
            QQInfo info = GsonUtils.jsonToBean(stringBuilder.toString(), QQInfo.class);
            sendMessage(ChatFormatting.GRAY + "����״̬: " + info.getStatus());
            sendMessage(ChatFormatting.GRAY + "������Ϣ: " + info.getMessage());
            sendMessage(ChatFormatting.GRAY + "QQ: " + info.getQq());
            sendMessage(ChatFormatting.GRAY + "�ֻ���: " + info.getPhone());
            sendMessage(ChatFormatting.GRAY + "����: " + info.getPhonediqu());
        }

        if (var1[0].equalsIgnoreCase("qqlm")) {
            String s = var1[1];
            StringBuilder stringBuilder = new StringBuilder();
            String inputLine;
            URL url;
            try {
                url = new URL("https://zy.xywlapi.cc/qqlm?qq=" + s);
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8));
                while ((inputLine = in.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
            } catch (IOException e) {
                OyVey.LOGGER.error(e);
                sendMessage(e.getMessage());
            }
            OyVey.LOGGER.info(stringBuilder.toString());
            QQlmInfo info = GsonUtils.jsonToBean(stringBuilder.toString(), QQlmInfo.class);
            sendMessage(ChatFormatting.GRAY + "����״̬: " + info.getStatus());
            sendMessage(ChatFormatting.GRAY + "������Ϣ: " + info.getMessage());
            sendMessage(ChatFormatting.GRAY + "QQ: " + info.getQq());
            sendMessage(ChatFormatting.GRAY + "QQ����: " + info.getQqlm());
        }


        if (var1[0].equalsIgnoreCase("wb")) {
            String s = var1[1];
            StringBuilder stringBuilder = new StringBuilder();
            String inputLine;
            URL url;
            try {
                url = new URL("https://zy.xywlapi.cc/wbapi?id=" + s);
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8));
                while ((inputLine = in.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
            } catch (IOException e) {
                OyVey.LOGGER.error(e);
                sendMessage(e.getMessage());
            }
            OyVey.LOGGER.info(stringBuilder.toString());
            WBInfo info = GsonUtils.jsonToBean(stringBuilder.toString(), WBInfo.class);
            sendMessage(ChatFormatting.GRAY + "����״̬: " + info.getStatus());
            sendMessage(ChatFormatting.GRAY + "������Ϣ: " + info.getMessage());
            sendMessage(ChatFormatting.GRAY + "ID: " + info.getID());
            sendMessage(ChatFormatting.GRAY + "�ֻ���: " + info.getPhone());
            sendMessage(ChatFormatting.GRAY + "����: " + info.getPhonediqu());
        }


        if (var1[0].equalsIgnoreCase("wbfc")) {
            String s = var1[1];
            StringBuilder stringBuilder = new StringBuilder();
            String inputLine;
            URL url;
            try {
                url = new URL("https://zy.xywlapi.cc/wbphone?phone=" + s);
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8));
                while ((inputLine = in.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
            } catch (IOException e) {
                OyVey.LOGGER.error(e);
                sendMessage(e.getMessage());
            }
            OyVey.LOGGER.info(stringBuilder.toString());
            WBInfo info = GsonUtils.jsonToBean(stringBuilder.toString(), WBInfo.class);
            sendMessage(ChatFormatting.GRAY + "����״̬: " + info.getStatus());
            sendMessage(ChatFormatting.GRAY + "������Ϣ: " + info.getMessage());
            sendMessage(ChatFormatting.GRAY + "ID: " + info.getID());
            sendMessage(ChatFormatting.GRAY + "�ֻ���: " + info.getPhone());
            sendMessage(ChatFormatting.GRAY + "����: " + info.getPhonediqu());
        }

        if (var1[0].equalsIgnoreCase("sfz")) {
            try {
                String sfzNum = var1[1];
                URL url = new URL("http://api.k780.com/?app=idcard.get&idcard=" + sfzNum + "&appkey=10003&sign=b59bc3ef6191eb9f747dd4e83c99f2a4&format=json");
                StringBuilder stringBuilder = new StringBuilder();
                String inputLine;
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), StandardCharsets.UTF_8));
                while ((inputLine = in.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }
                OyVey.LOGGER.info(stringBuilder.toString());
                SfzInfo info = GsonUtils.jsonToBean(stringBuilder.toString(), SfzInfo.class);
                sendMessage(ChatFormatting.GRAY + "success: " + info.getSuccess());
                sendMessage(ChatFormatting.GRAY + "status: " + info.getResult().getStatus());
                sendMessage(ChatFormatting.GRAY + "idcard: " + info.getResult().getIdcard());
                sendMessage(ChatFormatting.GRAY + "par: " + info.getResult().getPar());
                sendMessage(ChatFormatting.GRAY + "born: " + info.getResult().getBorn());
                sendMessage(ChatFormatting.GRAY + "sex: " + info.getResult().getSex());
                sendMessage(ChatFormatting.GRAY + "att: " + info.getResult().getAtt());
                sendMessage(ChatFormatting.GRAY + "postno: " + info.getResult().getPostno());
                sendMessage(ChatFormatting.GRAY + "areano: " + info.getResult().getAreano());
                sendMessage(ChatFormatting.GRAY + "style_simcall: " + info.getResult().getStyle_simcall());
                sendMessage(ChatFormatting.GRAY + "style_citynm: " + info.getResult().getStyle_citynm());
                sendMessage(ChatFormatting.GRAY + "msg: " + info.getResult().getMsg());
            } catch (IOException e) {
                sendMessage(e.getMessage());
                OyVey.LOGGER.error(e);
            }
        }
        if (var1[0].equalsIgnoreCase("douzi")) {
            sendMessage(ChatFormatting.GRAY + "������");
        }
        if (var1[0].equalsIgnoreCase("ssy")) {
            URLUtil.openUrl("https://www.hualigs.cn/image/63044958cbc5f.jpg");
        }
    }
}
