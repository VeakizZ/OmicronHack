package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class DoxxedActivator extends Module {
    public DoxxedActivator() {
        super("DoxxedActivator", ".doxxed help", Category.DOXXED, false, false, false);
    }

}
