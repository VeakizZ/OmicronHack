package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.util.URLUtil;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class AutoNicen extends Module {
    public AutoNicen() {
        super("AutoNicen", "", Category.DOXXED, false, false, false);
    }


    @Override
    public void onEnable() {
        URLUtil.openUrl("https://ip.nicen.cn/");
        setEnabled(false);
    }
}
