package me.alpha432.oyvey.features.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.doxxed.ForciblySearchActivator;
import me.alpha432.oyvey.util.URLUtil;

/**
 * created by Sparkle_A on 2022-08-23
 */
public class QQSearchCommand extends Command {

    public QQSearchCommand() {
        super("QQSearch", new String[]{"QQ"});
    }

    @Override
    public void execute(String[] var1) {
        if (!OyVey.moduleManager.isModuleEnabled(ForciblySearchActivator.class)) {
            sendMessage(ChatFormatting.GRAY + "ForciblySearchActivatorģ��δ����");
            OyVey.LOGGER.error("ForciblySearchActivator is disabled");
            return;
        }

        if (var1.length == 0) {
            sendMessage("��������");
            OyVey.LOGGER.error("Arguments error");
            return;
        }

        if (var1[0].equalsIgnoreCase("help")) {
            sendMessage(ChatFormatting.GRAY + OyVey.commandManager.getPrefix() + this.getName() + "QQ");
            return;
        }

        try {
            int i = Integer.parseInt(var1[0]);
            URLUtil.openUrl("https://res.abeim.cn/api-qq?qq=" + i);
            sendMessage("��ѯ�ɹ�!");
        } catch (NumberFormatException e) {
            sendMessage(e.getMessage());
            OyVey.LOGGER.error(e);
        }
    }
}
