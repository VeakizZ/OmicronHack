package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.util.URLUtil;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class AutoTG extends Module {
    public AutoTG() {
        super("AutoTG", "", Category.DOXXED, false, false, false);
    }


    @Override
    public void onEnable() {
        URLUtil.openUrl("https://www.privacys.club/");
        setEnabled(false);
    }
}
