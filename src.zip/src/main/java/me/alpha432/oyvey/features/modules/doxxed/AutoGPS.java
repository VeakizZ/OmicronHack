package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.util.URLUtil;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class AutoGPS extends Module {
    public AutoGPS() {
        super("AutoGPS", "", Category.DOXXED, false, false, false);
    }

    @Override
    public void onEnable() {
        URLUtil.openUrl("https://www.opengps.cn/Data/IP/ipplus.aspx");
        setEnabled(false);
    }
}
