package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;

/**
 * created by Sparkle_A on 2022-08-23
 */
public class ForciblySearchActivator extends Module {
    public ForciblySearchActivator() {
        super("ForciblySearchActivator", "", Category.DOXXED, false, false, false);
    }
}
