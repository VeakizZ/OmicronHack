package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.util.URLUtil;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class AntiDoxxed extends Module {
    public AntiDoxxed() {
        super("AntiDoxxed", "", Category.DOXXED, false, false, false);
    }

    @Override
    public void onEnable() {
        URLUtil.openUrl("https://sms24.me/en");
        URLUtil.openUrl("http://xnsms.com/");
        URLUtil.openUrl("https://yunduanxin.net/");
        setEnabled(false);
    }
}
