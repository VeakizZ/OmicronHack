package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.util.URLUtil;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class AntiDouzi extends Module {

    public AntiDouzi() {
        super("AntiDouzi", "Password: Douzi666", Category.DOXXED, false, false, false);
    }

    @Override
    public void onEnable() {
        URLUtil.openUrl("http://f3xk0urm04her.ysepan.com/");
        setEnabled(false);
    }
}
