package me.alpha432.oyvey.features.modules.combat;

import me.alpha432.oyvey.event.events.BlockEvent;
import me.alpha432.oyvey.event.events.PacketEvent;
import me.alpha432.oyvey.event.events.Render3DEvent;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.util.BlockUtil;
import me.alpha432.oyvey.util.InventoryUtil;
import me.alpha432.oyvey.util.RenderUtil;
import me.alpha432.oyvey.util.Timer;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.awt.*;
import java.util.Arrays;
import java.util.List;


public class InstantMine extends Module {
    private final Timer breakSuccess = new Timer();

    private static InstantMine INSTANCE = new InstantMine();

    private Setting<Boolean> creativeMode = register(new Setting("CreativeMode", Boolean.valueOf(true)));

    private Setting<Boolean> ghostHand = register(new Setting("GhostHand", Boolean.valueOf(true), v -> ((Boolean)this.creativeMode.getValue()).booleanValue()));

    public Setting<Boolean> fuck = register(new Setting("Super ghost hand", Boolean.valueOf(true), v -> ((Boolean)this.ghostHand.getValue()).booleanValue()));

    private Setting<Boolean> render = register(new Setting("Render", Boolean.valueOf(true)));

    private final List<Block> godBlocks = Arrays.asList(new Block[] { Blocks.AIR, (Block)Blocks.FLOWING_LAVA, (Block)Blocks.LAVA, (Block)Blocks.FLOWING_WATER, (Block)Blocks.WATER, Blocks.BEDROCK });

    private boolean cancelStart = false;

    private boolean empty = false;

    private EnumFacing facing;

    public static BlockPos breakPos;

    double manxi;

    public final Timer imerS;

    long times;

    public InstantMine() {
        super("PacketMine+", "InstantMine", Module.Category.COMBAT, true, false, false);
        this.manxi = 0.0D;
        this.imerS = new Timer();
        this.times = 0L;
        setInstance();
    }

    public static InstantMine getInstance() {
        if (INSTANCE != null)
            return INSTANCE;
        INSTANCE = new InstantMine();
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    public void onUpdate() {
        if (fullNullCheck())
            return;
        if (!((Boolean)this.creativeMode.getValue()).booleanValue())
            return;
        if (!this.cancelStart)
            return;
        if (InventoryUtil.getItemHotbars(Items.DIAMOND_PICKAXE) == -1)
            return;
        if (!((Boolean)this.fuck.getValue()).booleanValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1)
            return;
        if (this.godBlocks.contains(mc.world.getBlockState(breakPos).getBlock()))
            return;
        if (((Boolean)this.ghostHand.getValue()).booleanValue() && (((Boolean)this.fuck.getValue()).booleanValue() || InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) != -1) && InventoryUtil.getItemHotbars(Items.DIAMOND_PICKAXE) != -1) {
            int slotMain = mc.player.inventory.currentItem;
            if (mc.world.getBlockState(breakPos).getBlock() == Blocks.OBSIDIAN) {
                if (!this.breakSuccess.passedMs(1234L))
                    return;
                if (((Boolean)this.fuck.getValue()).booleanValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {
                    for (int i = 9; i < 36; i++) {
                        if (mc.player.inventory.getStackInSlot(i).getItem() == Items.DIAMOND_PICKAXE) {
                            mc.playerController.windowClick(mc.player.inventoryContainer.windowId, i, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
                            mc.playerController.updateController();
                            mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                            mc.playerController.windowClick(mc.player.inventoryContainer.windowId, i, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
                            mc.playerController.updateController();
                            return;
                        }
                    }
                    return;
                }
                mc.player.inventory.currentItem = InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE);
                mc.playerController.updateController();
                mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                mc.player.inventory.currentItem = slotMain;
                mc.playerController.updateController();
                return;
            }
            if (((Boolean)this.fuck.getValue()).booleanValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {
                for (int i = 9; i < 35; i++) {
                    if (mc.player.inventory.getStackInSlot(i).getItem() == Items.DIAMOND_PICKAXE) {
                        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, i, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
                        mc.playerController.updateController();
                        mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, i, mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)mc.player);
                        mc.playerController.updateController();
                        return;
                    }
                }
                return;
            }
            mc.player.inventory.currentItem = InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE);
            mc.playerController.updateController();
            mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
            mc.player.inventory.currentItem = slotMain;
            mc.playerController.updateController();
            return;
        }
        mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
    }

    public void onRender3D(Render3DEvent event) {
        if (fullNullCheck())
            return;
        if (((Boolean)this.render.getValue()).booleanValue() && ((Boolean)this.creativeMode.getValue()).booleanValue() && this.cancelStart) {
            if (this.godBlocks.contains(mc.world.getBlockState(breakPos).getBlock()))
                this.empty = true;
            if (this.imerS.passedMs(11L)) {
                if (this.manxi <= 10.0D)
                    this.manxi += 0.11D;
                this.imerS.reset();
            }
            final AxisAlignedBB axisAlignedBB = mc.world.getBlockState(breakPos).getSelectedBoundingBox((World)mc.world, breakPos);
            final double centerX = axisAlignedBB.minX + (axisAlignedBB.maxX - axisAlignedBB.minX) / 2.0D;
            final double centerY = axisAlignedBB.minY + (axisAlignedBB.maxY - axisAlignedBB.minY) / 2.0D;
            final double centerZ = axisAlignedBB.minZ + (axisAlignedBB.maxZ - axisAlignedBB.minZ) / 2.0D;
            final double progressValX = this.manxi * (axisAlignedBB.maxX - centerX) / 10.0D;
            final double progressValY = this.manxi * (axisAlignedBB.maxY - centerY) / 10.0D;
            final double progressValZ = this.manxi * (axisAlignedBB.maxZ - centerZ) / 10.0D;
            final AxisAlignedBB axisAlignedBB1 = new AxisAlignedBB(centerX - progressValX, centerY - progressValY, centerZ - progressValZ, centerX + progressValX, centerY + progressValY, centerZ + progressValZ);
            RenderUtil.drawBBBox(axisAlignedBB1, new Color(this.empty ? 0 : 255, this.empty ? 255 : 0, 44, 148), (new Color(this.empty ? 0 : 255, this.empty ? 255 : 0, 0, 144)).getAlpha());
            return;
        }
        if (!this.cancelStart)
            return;
        if (!((Boolean)this.render.getValue()).booleanValue())
            return;
        RenderUtil.drawBoxESP(breakPos, new Color(236, 235, 235), false, new Color(248, 248, 248, 148), 1.0F, true, true, 84, false);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (fullNullCheck())
            return;
        if (!(event.getPacket() instanceof CPacketPlayerDigging))
            return;
        CPacketPlayerDigging packet = (CPacketPlayerDigging)event.getPacket();
        if (packet.getAction() != CPacketPlayerDigging.Action.START_DESTROY_BLOCK)
            return;
        event.setCanceled(this.cancelStart);
    }

    @SubscribeEvent
    public void onBlockEvent(BlockEvent event) {
        if (fullNullCheck())
            return;
        if (!BlockUtil.canBreak(event.pos))
            return;
        if (breakPos != null &&
                breakPos.getX() == event.pos.getX() && breakPos.getY() == event.pos.getY() && breakPos.getZ() == event.pos.getZ())
            return;
        this.manxi = 0.0D;
        this.empty = false;
        this.cancelStart = false;
        breakPos = event.pos;
        this.breakSuccess.reset();
        this.facing = event.facing;
        if (breakPos == null)
            return;
        mc.player.swingArm(EnumHand.MAIN_HAND);
        mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, breakPos, this.facing));
        this.cancelStart = true;
        mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
        event.setCanceled(true);
    }

    public String getDisplayInfo() {
        if (!((Boolean)this.ghostHand.getValue()).booleanValue())
            return "Normal";
        return "Ghost";
    }
}

