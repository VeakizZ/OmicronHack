package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;

/**
 * created by Sparkle_A on 2022-08-24
 */
public class ZyjActivator extends Module {
    public ZyjActivator() {
        super("ZyjActivator", "", Category.DOXXED, false, false, false);
    }
}
