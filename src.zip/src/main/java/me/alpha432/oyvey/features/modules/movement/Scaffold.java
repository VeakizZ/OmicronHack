package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.features.modules.Module;

public class Scaffold
        extends Module {
    public Scaffold() {
        super("Scaffold", "Scaffold.", Module.Category.MOVEMENT, true, false, false);
    }
}

