package me.alpha432.oyvey.features.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.doxxed.ZyjActivator;
import me.alpha432.oyvey.util.URLUtil;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.Arrays;

/**
 * created by Sparkle_A on 2022-08-24
 */
public class ZyjCommand extends Command {
    public ZyjCommand() {//������
        super("Zyj", new String[]{"<add/cx>", "YourKey"});
    }

    @Override
    public void execute(String[] var1) {
        if (OyVey.moduleManager.getModuleByClass(ZyjActivator.class).isDisabled()) {
            sendMessage(ChatFormatting.GRAY + "ZyjActivatorģ��δ����");
            OyVey.LOGGER.error("ZyjActivator is disabled");
            return;
        }

        if (var1[0].equalsIgnoreCase("help")) {
            sendMessage(ChatFormatting.GRAY + OyVey.commandManager.getPrefix() + this.getName() + Arrays.toString(getCommands()));
        }

        if (var1.length == 1) {
            sendMessage(ChatFormatting.RED + "��������");
        }

        if (var1[0].equalsIgnoreCase("add")) {
            String key = var1[1];
            String s = "https://m.ishimeng.cn/?id=" + key + "&url=https://DouziSeaside.fun/";
            URLUtil.openUrl(s);
            StringSelection selection = new StringSelection(s);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(selection, selection);
            sendMessage("������ַ��: " + s + " �ѽ��临�Ƶ����ļ�����");
        }

        if (var1[0].equalsIgnoreCase("cx")) {
            String key = var1[1];
            URLUtil.openUrl("https://m.ishimeng.cn/ck.php?id=" + key);
        }
    }
}
