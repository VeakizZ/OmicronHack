package me.alpha432.oyvey.features.modules.doxxed;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.util.URLUtil;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class AutoHongZha extends Module {

    public AutoHongZha() {
        super("AutoHongZha", "", Category.DOXXED, false, false, false);
    }

    @Override
    public void onEnable() {
        URLUtil.openUrl("https://wwn.lanzoul.com/iY3px0a0ya7c");
        URLUtil.openUrl("https://www.lieyingcha.com/main/sms");
        URLUtil.openUrl("http://sms.67pw.cn/index.php");
        URLUtil.openUrl("https://2233cc.wodemo.net/entry/423229");
        setEnabled(false);
    }
}
