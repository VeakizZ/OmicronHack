package me.alpha432.oyvey.features.modules.player;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.event.events.MotionEvent;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.util.BlockUtils;
import me.alpha432.oyvey.util.InventoryUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HoleKickPlus extends Module {
    private final Setting<Float> range = this.register(new Setting<>("Range", 4.0f, 1.0f, 6.0f));

    private final Setting<Boolean> noGhost = register(new Setting<Boolean>("Packet", true));
    private final Setting<Boolean> autoDisable = this.register(new Setting<>("AutoDisable", true));

    int progress = 0;

    public HoleKickPlus() {
        super("HoleKick+", "AntiHoleFag", Category.PLAYER, true, false, false);
    }

    final static Minecraft mc = Minecraft.getMinecraft();
    EnumFacing facing;

    @Override
    public void onEnable() {
        progress = 0;
        super.onEnable();
    }


    @Override
    public void onUpdate() {
        for (Entity entity : mc.world.loadedEntityList) {
            if (entity == mc.player) continue;
            if (!OyVey.friendManager.isFriend(entity.getName()) && mc.player.getDistance(entity) > range.getValue())
                continue;

            if (entity instanceof EntityPlayer) {
                int oldSlot = mc.player.inventory.currentItem;

                int piston = InventoryUtil.pickItem(33);
                int power = InventoryUtil.pickItem(152);

                BlockPos pos = new BlockPos(entity).offset(EnumFacing.UP);

                if (piston == -1 || power == -1 || progress < 2) {
                    facing = getFacing(pos);
                    if (facing != null) {
                        progress++;
                    } else {
                        progress = 0;
                    }
                    return;
                }
                mc.player.inventory.currentItem = piston;
                mc.player.inventory.currentItem = InventoryUtil.findHotbarBlock(Blocks.PISTON);
                BlockUtils event = BlockUtils.isPlaceable(pos.offset(facing), 0, true);
                if (event != null) {
                    if (!event.doPlace(true)) {
                        return;
                    }


                    mc.player.inventory.currentItem = power;
                    mc.player.inventory.currentItem = InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK);
                    for (EnumFacing f : EnumFacing.values()) {
                        pos = new BlockPos(entity).offset(EnumFacing.UP).offset(facing);
                        event = BlockUtils.isPlaceable(pos.offset(f), 0, true);
                        if (BlockUtils.doPlace(event, true)) {
                            BlockUtils.doPlace(BlockUtils.isPlaceable(new BlockPos(entity), 0, false), false);
                            if (autoDisable.getValue()) {
                                this.disable();
                            }
                            InventoryUtil.switchToHotbarSlot(oldSlot, false);
                            return;
                        }
                    }
                }
            }
        }
    }


    public EnumFacing getFacing(BlockPos position) {
        for (EnumFacing f : EnumFacing.values()) {
            final BlockPos pos = new BlockPos(position);

            if (pos.offset(f).getY() != position.getY())
                continue;

            if (!mc.world.isAirBlock(pos.offset(f, -1).offset(EnumFacing.DOWN))) {
                if (mc.world.isAirBlock(pos.offset(f, -1))) {
                    if (mc.world.isAirBlock(pos.offset(f))) {
                        return f;
                    }
                }
            }
        }
        return null;
    }

    @SubscribeEvent
    public void MotionEvent(MotionEvent event) {

        if (progress > 0) {
            switch (facing) {
                case NORTH:
                    event.setYaw(180);
                    break;
                case SOUTH:
                    event.setYaw(0);
                    break;
                case WEST:
                    event.setYaw(90);
                    break;
                case EAST:
                    event.setYaw(-90);
                    break;
                default:
            }
            event.setPitch(0);
            progress++;
        }
    }
}