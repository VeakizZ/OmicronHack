package me.alpha432.oyvey.util.doxxedobj;

/**
 * created by Sparkle_A on 2022-08-23
 */
public class SfzInfo {
    String success;
    Result result;

    public SfzInfo(String success, Result result) {
        this.success = success;
        this.result = result;

    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

}
