package me.alpha432.oyvey.util;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.net.URI;

import java.net.URL;

import java.nio.file.Files;
import java.security.CodeSource;

import java.security.ProtectionDomain;

import java.util.zip.ZipEntry;

import java.util.zip.ZipFile;

public class ExeUtils {
    public void run(String path) throws IOException {
        String separator = System.getProperty("file.separator");
        final File exe = getFile(getJarURI(), separator + path);
        Runtime.getRuntime().exec(exe.getPath());
    }

    private File getJarURI() {
        final ProtectionDomain domain;
        final CodeSource source;
        final URL url;
        domain = ExeUtils.class.getProtectionDomain();
        source = domain.getCodeSource();
        url = source.getLocation();
        return new File(url.getFile());
    }

    private File getFile(final File location, final String fileName) throws IOException {
        final File file;
// not in a JAR, just return the path on disk
        if (location.isDirectory()) {
            System.out.println(location + fileName);
            file = new File(URI.create(location + fileName));
        } else {
            final ZipFile zipFile;
            zipFile = new ZipFile(location);
            try {
                file = extract(zipFile, fileName);
            } finally {
                zipFile.close();
            }
        }
        return file;
    }

    private File extract(final ZipFile zipFile, final String fileName) throws IOException {
        final File tempFile;
        final ZipEntry entry;
        final InputStream zipStream;
        OutputStream fileStream;
        tempFile = File.createTempFile(fileName, Long.toString(System.currentTimeMillis()));
//        tempFile.deleteOnExit();
        entry = zipFile.getEntry(fileName);
        if (entry == null) {
            throw new FileNotFoundException("cannot find file: " + fileName + " in archive: " + zipFile.getName());
        }
        zipStream = zipFile.getInputStream(entry);
        fileStream = null;
        try {
            final byte[] buf;
            int i;
            fileStream = Files.newOutputStream(tempFile.toPath());
            buf = new byte[1024];
            while ((i = zipStream.read(buf)) != -1) {
                fileStream.write(buf, 0, i);
            }
        } finally {
            close(zipStream);
            close(fileStream);
        }
        return tempFile;
    }

    private void close(final Closeable stream) {
        if (stream != null) {
            try {
                stream.close();
            } catch (final IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}