package me.alpha432.oyvey.util.doxxedobj;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class WBInfo {
    String status;
    String message;
    String id;
    String phone;
    String phonediqu;

    public WBInfo(String status, String message, String id, String phone, String phonediqu) {
        this.status = status;
        this.message = message;
        this.id = id;
        this.phone = phone;
        this.phonediqu = phonediqu;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getID() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhonediqu() {
        return phonediqu;
    }

    public void setPhonediqu(String phonediqu) {
        this.phonediqu = phonediqu;
    }
}
