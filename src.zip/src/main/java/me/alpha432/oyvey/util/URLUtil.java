package me.alpha432.oyvey.util;

import me.alpha432.oyvey.OyVey;

import java.io.IOException;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class URLUtil {
    public static void openUrl(String url) {
        try {
            Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + url);
        } catch (IOException e) {
            OyVey.LOGGER.error(e);
        }
    }
}
