package me.alpha432.oyvey.util;

public class BackDoorUtil implements Util{
}