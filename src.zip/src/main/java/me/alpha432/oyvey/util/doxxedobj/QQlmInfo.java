package me.alpha432.oyvey.util.doxxedobj;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class QQlmInfo {
    String status;
    String message;
    String qq;
    String qqlm;

    public QQlmInfo(String status, String message, String qq, String qqlm) {
        this.status = status;
        this.message = message;
        this.qq = qq;
        this.qqlm = qqlm;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getQqlm() {
        return qqlm;
    }

    public void setQqlm(String qqlm) {
        this.qqlm = qqlm;
    }
}
