package me.alpha432.oyvey.util.doxxedobj;

/**
 * created by Sparkle_A on 2022-08-22
 */
public class LOLInfo {
    String status;
    String message;
    String qq;
    String name;
    String daqu;

    public LOLInfo(String status, String message, String qq, String name, String daqu) {
        this.status = status;
        this.message = message;
        this.qq = qq;
        this.name = name;
        this.daqu = daqu;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDaqu() {
        return daqu;
    }

    public void setDaqu(String daqu) {
        this.daqu = daqu;
    }
}
